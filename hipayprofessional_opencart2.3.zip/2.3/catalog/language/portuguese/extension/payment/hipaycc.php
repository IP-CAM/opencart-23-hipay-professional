<?php
/*
Hipay Wallet & Direct Extension for Opencart 2.1.x
Author: diogojosferreira@gmail.com
*/
?>
<?php
// Heading
$_['heading_title']      = 'Hipay Wallet/Direct';
 
// Text
$_['text_title']         = 'Hipay - Pague com cartão de Crédito e métodos de pagamento locais';

$_['hipay_pending']      = 'Hipay selecionado (Hipay)';
$_['hipay_waiting']      = 'Aguarda confirmação do pagamento (Hipay)';
$_['hipay_cancelled']    = 'Pagamento cancelado (Hipay)';
$_['hipay_error']        = 'Erro no pagamento (Hipay)';
$_['hipay_error_ack']    = ' - Erro no processamento do pagamento (Hipay)';
$_['hipay_success']      = 'Pagamento Capturado (Hipay)';


?>