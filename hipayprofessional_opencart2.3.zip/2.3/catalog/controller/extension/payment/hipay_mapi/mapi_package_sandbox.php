<?php
$_mapi_dir=dirname(__FILE__);

require_once($_mapi_dir.'/mapi_defs_sandbox.php');
require_once($_mapi_dir.'/mapi_utils.php');
require_once($_mapi_dir.'/mapi_utf8.php');
require_once($_mapi_dir.'/mapi_xml.php');
require_once($_mapi_dir.'/mapi_send_xml.php');
require_once($_mapi_dir.'/mapi_comm_xml.php');
require_once($_mapi_dir.'/mapi_lockable.php');

require_once($_mapi_dir.'/mapi_tax.php');
require_once($_mapi_dir.'/mapi_affiliate.php');
require_once($_mapi_dir.'/mapi_item.php');
require_once($_mapi_dir.'/mapi_installment.php');
require_once($_mapi_dir.'/mapi_product.php');
require_once($_mapi_dir.'/mapi_paymentparams.php');
require_once($_mapi_dir.'/mapi_order.php');
require_once($_mapi_dir.'/mapi_payment.php');
require_once($_mapi_dir.'/mapi_multiplepayment.php');
require_once($_mapi_dir.'/mapi_simplepayment.php');
?>