<?php

class ModelPaymentHipaycc extends Model {

	public function install() {
	}

	public function uninstall() {
	}

}
